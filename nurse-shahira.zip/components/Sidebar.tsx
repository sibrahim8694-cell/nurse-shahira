import React from 'react';
import { NAV_ITEMS } from '../constants';
import { AppSection } from '../types';
import { Stethoscope } from 'lucide-react';

interface SidebarProps {
  currentSection: AppSection;
  onNavigate: (section: AppSection) => void;
}

export const Sidebar: React.FC<SidebarProps> = ({ currentSection, onNavigate }) => {
  return (
    <div className="hidden md:flex flex-col w-64 bg-white h-full border-l border-slate-200 shadow-sm">
      <div className="p-6 flex items-center gap-3 border-b border-slate-100">
        <div className="bg-teal-600 p-2 rounded-lg">
          <Stethoscope className="text-white w-6 h-6" />
        </div>
        <div>
          <h1 className="font-bold text-xl text-teal-900">Nurse Shahira</h1>
          <p className="text-xs text-slate-500">رفيقك في التمريض</p>
        </div>
      </div>

      <nav className="flex-1 p-4 space-y-2 overflow-y-auto">
        {NAV_ITEMS.map((item) => (
          <button
            key={item.id}
            onClick={() => onNavigate(item.id)}
            className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all duration-200 ${
              currentSection === item.id
                ? 'bg-teal-50 text-teal-700 shadow-sm font-bold border border-teal-100'
                : 'text-slate-500 hover:bg-slate-50 hover:text-slate-700'
            }`}
          >
            <item.icon className={`w-5 h-5 ${currentSection === item.id ? 'stroke-[2.5px]' : 'stroke-2'}`} />
            <span>{item.label}</span>
          </button>
        ))}
      </nav>

      <div className="p-4 border-t border-slate-100">
        <div className="bg-gradient-to-br from-teal-500 to-teal-700 rounded-xl p-4 text-white">
          <p className="text-sm font-medium mb-1">هل تحتاج مساعدة؟</p>
          <p className="text-xs text-teal-100 mb-3">تحدث مع المساعد الذكي الآن</p>
          <button 
            onClick={() => onNavigate(AppSection.AI_ASSISTANT)}
            className="w-full bg-white/20 hover:bg-white/30 text-xs py-2 rounded-lg transition"
          >
            اسأل شهيرة
          </button>
        </div>
      </div>
    </div>
  );
};