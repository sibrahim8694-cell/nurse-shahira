
import React, { useState } from 'react';
import { EMERGENCY_PROTOCOLS } from '../constants';
import { AlertTriangle, Stethoscope, Activity, Brain, Youtube, ExternalLink } from 'lucide-react';

export const SectionEmergency: React.FC = () => {
  const [filter, setFilter] = useState<string>('All');

  const categories = ['All', 'Cardiac', 'Respiratory', 'Trauma', 'Other'];

  const filteredProtocols = filter === 'All' 
    ? EMERGENCY_PROTOCOLS 
    : EMERGENCY_PROTOCOLS.filter(p => p.category === filter);

  const getIcon = (category: string) => {
    switch(category) {
        case 'Cardiac': return <Activity className="text-red-500" />;
        case 'Neurological': return <Brain className="text-purple-500" />;
        case 'Trauma': return <AlertTriangle className="text-orange-500" />;
        default: return <Stethoscope className="text-blue-500" />;
    }
  };

  return (
    <div className="p-4 md:p-8 pb-24 max-w-5xl mx-auto animate-fade-in">
      <div className="bg-red-50 border border-red-100 p-6 rounded-2xl mb-8 flex items-start gap-4">
        <div className="p-3 bg-red-100 rounded-full animate-pulse text-red-600">
            <AlertTriangle size={32} />
        </div>
        <div>
            <h2 className="text-3xl font-bold text-slate-800 mb-2">دليل الطوارئ الشامل</h2>
            <p className="text-slate-600">بروتوكولات التعامل مع الحالات الحرجة خطوة بخطوة. <br/>
            <span className="text-red-600 text-sm font-bold">تنبيه: يجب استدعاء الطبيب المختص فوراً في جميع هذه الحالات.</span>
            </p>
        </div>
      </div>

      {/* Filters */}
      <div className="flex gap-2 overflow-x-auto pb-4 mb-4 scrollbar-hide">
        {categories.map(cat => (
            <button
                key={cat}
                onClick={() => setFilter(cat)}
                className={`px-4 py-2 rounded-full text-sm font-bold whitespace-nowrap transition-all ${
                    filter === cat 
                    ? 'bg-slate-800 text-white shadow-lg' 
                    : 'bg-white text-slate-500 border border-slate-200 hover:bg-slate-50'
                }`}
            >
                {cat === 'All' ? 'الكل' : cat}
            </button>
        ))}
      </div>

      <div className="grid grid-cols-1 gap-6">
        {filteredProtocols.map((protocol, index) => (
          <div key={index} className={`rounded-xl border bg-white shadow-sm overflow-hidden hover:shadow-md transition-shadow ${
            protocol.priority === 'Critical' ? 'border-l-4 border-l-red-500' : 'border-l-4 border-l-orange-500'
          }`}>
            <div className="p-5 border-b border-slate-100 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
                <div className="flex items-center gap-3">
                    <div className="p-2 bg-slate-50 rounded-lg">
                        {getIcon(protocol.category)}
                    </div>
                    <div>
                        <h3 className="text-xl font-bold text-slate-800">{protocol.title}</h3>
                        <span className="text-xs text-slate-400">{protocol.category}</span>
                    </div>
                </div>
                <div className="flex items-center gap-2 self-end sm:self-auto">
                    <span className={`px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wide shadow-sm ${
                        protocol.priority === 'Critical' ? 'bg-red-100 text-red-700 border border-red-200' : 'bg-orange-100 text-orange-700 border border-orange-200'
                    }`}>
                        {protocol.priority}
                    </span>
                </div>
            </div>
            
            <div className="p-6 bg-slate-50/50">
              <div className="space-y-4 mb-6">
                {protocol.steps.map((step, idx) => (
                  <div key={idx} className="flex items-start gap-4 p-3 bg-white rounded-lg border border-slate-100 shadow-sm">
                    <div className={`w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold flex-shrink-0 mt-0.5 ${
                        protocol.priority === 'Critical' ? 'bg-red-100 text-red-600' : 'bg-orange-100 text-orange-600'
                    }`}>
                        {idx + 1}
                    </div>
                    <span className="text-slate-700 font-medium text-base">{step}</span>
                  </div>
                ))}
              </div>

              {/* Video Button in Emergency Section */}
              {protocol.videoUrl && (
                 <div className="flex justify-end border-t border-slate-200 pt-4">
                    <a 
                        href={protocol.videoUrl}
                        target="_blank"
                        rel="noreferrer"
                        className="flex items-center gap-2 text-red-600 hover:text-red-700 font-bold bg-white border border-red-100 hover:border-red-300 px-4 py-2 rounded-lg shadow-sm transition-all"
                    >
                        <Youtube size={20} />
                        <span>شاهد قائمة فيديوهات ذات صلة</span>
                        <ExternalLink size={16} />
                    </a>
                 </div>
              )}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
