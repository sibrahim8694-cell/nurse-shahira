import React from 'react';
import { NAV_ITEMS } from '../constants';
import { AppSection } from '../types';

interface MobileNavProps {
  currentSection: AppSection;
  onNavigate: (section: AppSection) => void;
}

export const MobileNav: React.FC<MobileNavProps> = ({ currentSection, onNavigate }) => {
  // Show only 5 items on mobile to fit standard screens, usually primary ones
  const mobileItems = NAV_ITEMS.filter(item => item.id !== AppSection.REFERENCES).slice(0, 5);

  return (
    <div className="md:hidden fixed bottom-0 left-0 right-0 bg-white border-t border-slate-200 shadow-[0_-4px_6px_-1px_rgba(0,0,0,0.05)] z-50">
      <div className="flex justify-around items-center px-2 py-2">
        {mobileItems.map((item) => (
          <button
            key={item.id}
            onClick={() => onNavigate(item.id)}
            className={`flex flex-col items-center justify-center p-2 w-full rounded-lg transition-colors ${
              currentSection === item.id
                ? 'text-teal-600'
                : 'text-slate-400 hover:text-slate-600'
            }`}
          >
            <item.icon className={`w-6 h-6 mb-1 ${currentSection === item.id ? 'stroke-[2.5px]' : ''}`} />
            <span className="text-[10px] font-medium">{item.label}</span>
          </button>
        ))}
      </div>
    </div>
  );
};