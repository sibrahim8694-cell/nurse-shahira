
import React, { useState, useEffect } from 'react';
import { QUIZ_DATA } from '../constants';
import { QuizQuestion } from '../types';
import { CheckCircle, XCircle, RefreshCw, Trophy, ClipboardCheck } from 'lucide-react';

export const SectionQuizzes: React.FC = () => {
  const [questions, setQuestions] = useState<QuizQuestion[]>([]);
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [score, setScore] = useState(0);
  const [showScore, setShowScore] = useState(false);
  const [selectedOption, setSelectedOption] = useState<number | null>(null);
  const [isAnswerChecked, setIsAnswerChecked] = useState(false);

  // Initialize quiz with shuffled questions
  useEffect(() => {
    startNewQuiz();
  }, []);

  const startNewQuiz = () => {
    // Shuffle array and pick first 20
    const shuffled = [...QUIZ_DATA]
      .sort(() => Math.random() - 0.5)
      .slice(0, 20);
    
    setQuestions(shuffled);
    setScore(0);
    setCurrentQuestionIndex(0);
    setShowScore(false);
    setSelectedOption(null);
    setIsAnswerChecked(false);
  };

  // Handle loading state
  if (questions.length === 0) {
    return (
      <div className="flex items-center justify-center h-[50vh]">
        <div className="w-8 h-8 border-4 border-teal-600 border-t-transparent rounded-full animate-spin"></div>
      </div>
    );
  }

  const currentQuestion = questions[currentQuestionIndex];

  const handleOptionClick = (index: number) => {
    if (isAnswerChecked) return;
    setSelectedOption(index);
  };

  const checkAnswer = () => {
    setIsAnswerChecked(true);
    if (selectedOption === currentQuestion.correctAnswer) {
      setScore(score + 1);
    }
  };

  const handleNext = () => {
    setSelectedOption(null);
    setIsAnswerChecked(false);
    if (currentQuestionIndex < questions.length - 1) {
      setCurrentQuestionIndex(currentQuestionIndex + 1);
    } else {
      setShowScore(true);
    }
  };

  if (showScore) {
    return (
      <div className="p-8 flex flex-col items-center justify-center min-h-[60vh] animate-fade-in">
        <div className="bg-white p-10 rounded-3xl shadow-xl text-center max-w-md w-full border border-slate-100">
          <div className="w-24 h-24 bg-yellow-100 rounded-full flex items-center justify-center mx-auto mb-6 text-yellow-500">
            <Trophy size={48} />
          </div>
          <h2 className="text-2xl font-bold text-slate-800 mb-2">اكتمل الاختبار!</h2>
          <p className="text-slate-500 mb-6">لقد قمت بالإجابة على جميع الأسئلة.</p>
          
          <div className="text-5xl font-bold text-teal-600 mb-2">{score} / {questions.length}</div>
          <p className="text-sm text-slate-400 mb-8">النتيجة النهائية</p>

          <button 
            onClick={startNewQuiz}
            className="w-full bg-teal-600 text-white py-4 rounded-xl font-bold hover:bg-teal-700 transition flex items-center justify-center gap-2"
          >
            <RefreshCw size={20} />
            إعادة الاختبار (أسئلة جديدة)
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="p-4 md:p-8 pb-24 max-w-3xl mx-auto animate-fade-in">
      <div className="mb-8 flex items-center justify-between">
        <div>
             <h2 className="text-2xl font-bold text-slate-800 flex items-center gap-2">
                <ClipboardCheck className="text-teal-600" />
                اختبار المعلومات
             </h2>
             <p className="text-slate-500 text-sm">السؤال {currentQuestionIndex + 1} من {questions.length}</p>
        </div>
        <div className="bg-teal-50 text-teal-700 px-4 py-2 rounded-lg font-bold">
            النقاط: {score}
        </div>
      </div>

      <div className="bg-white rounded-3xl shadow-sm border border-slate-200 overflow-hidden">
        {/* Progress Bar */}
        <div className="w-full bg-slate-100 h-2">
            <div 
                className="bg-teal-500 h-2 transition-all duration-500"
                style={{ width: `${((currentQuestionIndex + 1) / questions.length) * 100}%` }}
            ></div>
        </div>

        <div className="p-6 md:p-8">
          <h3 className="text-xl font-bold text-slate-800 mb-6 leading-relaxed">
            {currentQuestion.question}
          </h3>

          <div className="space-y-3">
            {currentQuestion.options.map((option, index) => {
              let optionStyle = "border-slate-200 hover:bg-slate-50";
              
              if (isAnswerChecked) {
                if (index === currentQuestion.correctAnswer) {
                  optionStyle = "bg-green-100 border-green-500 text-green-800";
                } else if (index === selectedOption) {
                  optionStyle = "bg-red-100 border-red-500 text-red-800";
                } else {
                    optionStyle = "opacity-50";
                }
              } else if (selectedOption === index) {
                optionStyle = "border-teal-500 bg-teal-50 text-teal-800 ring-1 ring-teal-500";
              }

              return (
                <button
                  key={index}
                  onClick={() => handleOptionClick(index)}
                  disabled={isAnswerChecked}
                  className={`w-full text-right p-4 rounded-xl border-2 transition-all font-medium flex items-center justify-between ${optionStyle}`}
                >
                  <span>{option}</span>
                  {isAnswerChecked && index === currentQuestion.correctAnswer && <CheckCircle className="text-green-600" />}
                  {isAnswerChecked && index === selectedOption && index !== currentQuestion.correctAnswer && <XCircle className="text-red-600" />}
                </button>
              );
            })}
          </div>
        </div>

        <div className="p-6 border-t border-slate-100 bg-slate-50 flex justify-between items-center">
            <div className="flex-1">
                {isAnswerChecked && (
                    <p className="text-sm text-slate-600 animate-fade-in">
                        <span className="font-bold block mb-1">الشرح:</span>
                        {currentQuestion.explanation}
                    </p>
                )}
            </div>
            <div className="flex-shrink-0 ml-4">
                {!isAnswerChecked ? (
                    <button 
                        onClick={checkAnswer}
                        disabled={selectedOption === null}
                        className="bg-teal-600 text-white px-8 py-3 rounded-xl font-bold hover:bg-teal-700 transition disabled:opacity-50 disabled:cursor-not-allowed"
                    >
                        تحقق
                    </button>
                ) : (
                    <button 
                        onClick={handleNext}
                        className="bg-slate-800 text-white px-8 py-3 rounded-xl font-bold hover:bg-slate-900 transition"
                    >
                        {currentQuestionIndex < questions.length - 1 ? 'السؤال التالي' : 'إنهاء'}
                    </button>
                )}
            </div>
        </div>
      </div>
    </div>
  );
};
