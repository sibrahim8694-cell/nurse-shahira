
import React from 'react';
import { REFERENCES_FILES } from '../constants';
import { FileText, Download, Book, Pill, Siren, Bandage, Library, ExternalLink } from 'lucide-react';

export const SectionReferences: React.FC = () => {
  const getFileIcon = (iconType: string) => {
      if (iconType === 'pill') return <Pill size={28} />;
      if (iconType === 'siren') return <Siren size={28} />;
      if (iconType === 'bandage') return <Bandage size={28} />;
      if (iconType === 'book') return <Book size={28} />;
      return <FileText size={28} />;
  };

  return (
    <div className="p-4 md:p-8 pb-24 max-w-5xl mx-auto animate-fade-in">
      <div className="mb-8 flex items-center gap-3">
        <div className="bg-blue-100 p-3 rounded-xl text-blue-600">
             <Library size={32} />
        </div>
        <div>
            <h2 className="text-3xl font-bold text-slate-800">المكتبة الرقمية</h2>
            <p className="text-slate-500">تحميل مراجع وكتب طبية من مصادر خارجية معتمدة.</p>
        </div>
      </div>

      <div className="bg-white rounded-2xl shadow-lg border border-slate-200 overflow-hidden">
        <div className="grid grid-cols-1 divide-y divide-slate-100">
          {REFERENCES_FILES.map((file, index) => (
            <div key={index} className="p-5 hover:bg-slate-50 transition-colors flex flex-col sm:flex-row sm:items-center justify-between gap-4 group">
              <div className="flex items-center gap-4">
                <div className={`w-14 h-14 rounded-xl flex items-center justify-center shadow-sm transition-transform group-hover:scale-110 ${
                    file.category === 'Emergency' ? 'bg-red-50 text-red-500' : 
                    file.category === 'Pharmacology' ? 'bg-purple-50 text-purple-500' :
                    'bg-teal-50 text-teal-600'
                }`}>
                  {getFileIcon(file.icon)}
                </div>
                <div>
                  <h4 className="font-bold text-lg text-slate-800 group-hover:text-teal-700 transition-colors">{file.title}</h4>
                  <div className="flex flex-wrap gap-3 text-xs text-slate-400 mt-1">
                    <span className="bg-slate-100 px-2 py-1 rounded font-medium text-slate-600 uppercase border border-slate-200">{file.type}</span>
                    <span className="flex items-center gap-1 bg-slate-100 px-2 py-1 rounded border border-slate-200">{file.size}</span>
                    <span className={`px-2 py-1 rounded border ${
                        file.category === 'Emergency' ? 'bg-red-50 text-red-600 border-red-100' : 'bg-teal-50 text-teal-600 border-teal-100'
                    }`}>
                        {file.category}
                    </span>
                  </div>
                </div>
              </div>
              
              <a 
                href={file.downloadUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center justify-center gap-2 bg-teal-600 text-white border border-teal-600 px-6 py-3 rounded-xl hover:bg-teal-700 hover:border-teal-700 hover:shadow-md transition-all active:scale-95 w-full sm:w-auto font-bold decoration-0"
              >
                <Download size={18} />
                <span>تحميل من المصدر</span>
                <ExternalLink size={14} className="opacity-70" />
              </a>
            </div>
          ))}
        </div>
      </div>
      
      <div className="mt-8 bg-gradient-to-r from-teal-50 to-slate-50 p-6 rounded-xl border border-teal-100 flex items-start gap-4 shadow-sm">
        <div className="bg-white p-2 rounded-full shadow-sm text-teal-600">
             <Book size={24} />
        </div>
        <div>
            <h3 className="font-bold text-teal-900 text-lg">تنبيه هام</h3>
            <p className="text-teal-800 text-sm mt-1 leading-relaxed">
                هذه الملفات مستضافة على مواقع خارجية (مثل وزارة الصحة، منظمة الصحة العالمية). عند الضغط على التحميل سيتم توجيهك للمصدر الأصلي للحصول على أحدث نسخة.
            </p>
        </div>
      </div>
    </div>
  );
};
