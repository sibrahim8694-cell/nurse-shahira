
import React, { useState } from 'react';
import { FIRST_AID_VIDEOS } from '../constants';
import { PlayCircle, ChevronDown, ChevronUp, BookOpen, Youtube, ExternalLink } from 'lucide-react';

export const SectionFirstAid: React.FC = () => {
  const [expandedId, setExpandedId] = useState<string | null>(null);

  const toggleExpand = (title: string) => {
    if (expandedId === title) {
      setExpandedId(null);
    } else {
      setExpandedId(title);
    }
  };

  return (
    <div className="p-4 md:p-8 pb-24 max-w-4xl mx-auto animate-fade-in">
      <div className="mb-8 bg-white p-6 rounded-2xl border border-teal-100 shadow-sm">
        <h2 className="text-3xl font-bold text-teal-800 mb-2 flex items-center gap-2">
            <BookOpen className="w-8 h-8" />
            الإسعافات الأولية
        </h2>
        <p className="text-slate-500">شرح تفصيلي لخطوات الإسعاف الأولي مع روابط لفيديوهات تعليمية.</p>
      </div>

      <div className="space-y-6">
        {FIRST_AID_VIDEOS.map((item, index) => (
          <div key={index} className="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden hover:shadow-md transition-all duration-300">
            {/* Header */}
            <div 
                onClick={() => toggleExpand(item.title)}
                className="p-5 flex items-center justify-between cursor-pointer bg-slate-50 hover:bg-slate-100 transition-colors"
            >
                <div className="flex items-center gap-4">
                    <div className="w-12 h-12 bg-teal-100 rounded-full flex items-center justify-center text-teal-600 font-bold">
                        {index + 1}
                    </div>
                    <div>
                        <h3 className="text-lg font-bold text-slate-800">{item.title}</h3>
                        <span className="text-xs bg-white px-2 py-1 rounded border border-slate-200 text-slate-500">
                            {item.category}
                        </span>
                    </div>
                </div>
                {expandedId === item.title ? <ChevronUp className="text-slate-400" /> : <ChevronDown className="text-slate-400" />}
            </div>

            {/* Content */}
            {expandedId === item.title && (
                <div className="p-6 border-t border-slate-100 bg-white animate-fade-in">
                    {/* Text Explanation */}
                    <div className="mb-8">
                        <h4 className="font-bold text-teal-700 mb-2 text-lg">شرح الحالة:</h4>
                        <p className="text-slate-600 leading-relaxed mb-4 bg-teal-50 p-4 rounded-lg border border-teal-100 text-sm md:text-base">
                            {item.explanation}
                        </p>

                        <h4 className="font-bold text-teal-700 mb-3 text-lg">الخطوات:</h4>
                        <ul className="space-y-3 mb-6">
                            {item.steps.map((step, idx) => (
                                <li key={idx} className="flex items-start gap-3">
                                    <span className="flex-shrink-0 w-6 h-6 rounded-full bg-teal-600 text-white flex items-center justify-center text-sm font-bold mt-0.5">
                                        {idx + 1}
                                    </span>
                                    <span className="text-slate-700 font-medium">{step}</span>
                                </li>
                            ))}
                        </ul>
                    </div>

                    {/* Video Link Section */}
                    <div className="mt-6 pt-6 border-t border-slate-100">
                         <a 
                            href={item.videoUrl}
                            target="_blank"
                            rel="noreferrer"
                            className="flex items-center justify-center gap-3 bg-red-600 hover:bg-red-700 text-white p-4 rounded-xl font-bold transition-all hover:scale-[1.02] shadow-md w-full md:w-auto mx-auto"
                         >
                            <Youtube size={24} />
                            <span>اضغط هنا لمشاهدة قائمة فيديوهات الشرح</span>
                            <ExternalLink size={18} className="opacity-70" />
                         </a>
                         <p className="text-center text-slate-400 text-xs mt-2">سيتم فتح يوتيوب في نافذة جديدة لعرض أفضل الفيديوهات التعليمية</p>
                    </div>
                </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
};
