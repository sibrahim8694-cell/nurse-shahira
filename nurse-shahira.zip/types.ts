
import { LucideIcon } from 'lucide-react';

export enum AppSection {
  HOME = 'HOME',
  FIRST_AID = 'FIRST_AID',
  REFERENCES = 'REFERENCES',
  EMERGENCY = 'EMERGENCY',
  AI_ASSISTANT = 'AI_ASSISTANT',
  QUIZZES = 'QUIZZES'
}

export interface NavItem {
  id: AppSection;
  label: string;
  icon: LucideIcon;
}

export interface VideoResource {
  title: string;
  explanation: string;
  steps: string[];
  videoUrl: string; // Direct URL to YouTube video or playlist search
  category: string;
}

export interface FileReference {
  title: string;
  type: 'PDF' | 'DOCX' | 'BOOK';
  size: string;
  category: string;
  icon: string;
  downloadUrl: string; // External URL to download the file
}

export interface EmergencyProtocol {
  title: string;
  category: 'Cardiac' | 'Trauma' | 'Respiratory' | 'Neurological' | 'Other';
  steps: string[];
  priority: 'High' | 'Critical' | 'Medium';
  videoUrl?: string;
}

export interface ChatMessage {
  id: string;
  role: 'user' | 'model';
  text: string;
  timestamp: Date;
}

export interface QuizQuestion {
  id: number;
  question: string;
  options: string[];
  correctAnswer: number;
  explanation: string;
}
