import React, { useState } from 'react';
import { Sidebar } from './components/Sidebar';
import { MobileNav } from './components/MobileNav';
import { AppSection } from './types';
import { SectionFirstAid } from './components/SectionFirstAid';
import { SectionReferences } from './components/SectionReferences';
import { SectionEmergency } from './components/SectionEmergency';
import { SectionAI } from './components/SectionAI';
import { SectionQuizzes } from './components/SectionQuizzes';
import { Activity, ArrowRight, Bandage, Library, Bot } from 'lucide-react';

// Home Section with Navigation Handlers
const HomeSection: React.FC<{ onNavigate: (section: AppSection) => void }> = ({ onNavigate }) => (
  <div className="p-6 md:p-12 max-w-5xl mx-auto animate-fade-in">
    <div className="bg-gradient-to-br from-teal-600 to-emerald-800 rounded-3xl p-8 md:p-12 text-white shadow-xl mb-8 relative overflow-hidden">
      <div className="absolute top-0 left-0 w-full h-full opacity-10 pointer-events-none">
        <Activity size={400} className="absolute -right-20 -bottom-20 rotate-12" />
      </div>
      <div className="relative z-10">
        <h1 className="text-3xl md:text-5xl font-bold mb-4 leading-tight">
          مرحباً بك في <br/> Nurse Shahira
        </h1>
        <p className="text-teal-100 text-lg md:text-xl mb-8 max-w-xl leading-relaxed">
          تطبيقك المتكامل للدراسة، المراجع، والمساعدة الفورية في عالم التمريض. تعلمي وتطوري معنا.
        </p>
        <button 
          onClick={() => onNavigate(AppSection.FIRST_AID)}
          className="bg-white text-teal-800 px-8 py-3 rounded-xl font-bold hover:bg-teal-50 transition flex items-center gap-2 shadow-lg hover:scale-105 active:scale-95 transform duration-200"
        >
          <span>ابدأ التعلم الآن</span>
          <ArrowRight size={20} className="rotate-180" />
        </button>
      </div>
    </div>

    <h3 className="text-xl font-bold text-slate-800 mb-4">الأقسام الرئيسية</h3>
    <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
      <button 
        onClick={() => onNavigate(AppSection.FIRST_AID)}
        className="bg-white p-6 rounded-2xl border border-slate-100 shadow-sm hover:shadow-md transition text-right group"
      >
        <div className="w-14 h-14 bg-orange-100 rounded-2xl flex items-center justify-center text-orange-600 mb-4 group-hover:scale-110 transition-transform">
          <Bandage size={28} />
        </div>
        <h3 className="font-bold text-lg mb-2 text-slate-800 group-hover:text-orange-600 transition-colors">الإسعافات الأولية</h3>
        <p className="text-slate-500 text-sm">شرح تفصيلي وفيديوهات لكل حالات الطوارئ والإصابات.</p>
      </button>

      <button 
        onClick={() => onNavigate(AppSection.REFERENCES)}
        className="bg-white p-6 rounded-2xl border border-slate-100 shadow-sm hover:shadow-md transition text-right group"
      >
        <div className="w-14 h-14 bg-blue-100 rounded-2xl flex items-center justify-center text-blue-600 mb-4 group-hover:scale-110 transition-transform">
          <Library size={28} />
        </div>
        <h3 className="font-bold text-lg mb-2 text-slate-800 group-hover:text-blue-600 transition-colors">المكتبة والمراجع</h3>
        <p className="text-slate-500 text-sm">تحميل مباشر للملفات، الكتب، وبروتوكولات التمريض.</p>
      </button>

      <button 
        onClick={() => onNavigate(AppSection.AI_ASSISTANT)}
        className="bg-white p-6 rounded-2xl border border-slate-100 shadow-sm hover:shadow-md transition text-right group"
      >
        <div className="w-14 h-14 bg-purple-100 rounded-2xl flex items-center justify-center text-purple-600 mb-4 group-hover:scale-110 transition-transform">
          <Bot size={28} />
        </div>
        <h3 className="font-bold text-lg mb-2 text-slate-800 group-hover:text-purple-600 transition-colors">اسأل شهيرة</h3>
        <p className="text-slate-500 text-sm">مساعد ذكي للإجابة على أسئلتك الطبية والدراسية فوراً.</p>
      </button>
    </div>
  </div>
);

const App: React.FC = () => {
  const [currentSection, setCurrentSection] = useState<AppSection>(AppSection.HOME);

  const renderContent = () => {
    switch (currentSection) {
      case AppSection.HOME:
        return <HomeSection onNavigate={setCurrentSection} />;
      case AppSection.FIRST_AID:
        return <SectionFirstAid />;
      case AppSection.REFERENCES:
        return <SectionReferences />;
      case AppSection.EMERGENCY:
        return <SectionEmergency />;
      case AppSection.AI_ASSISTANT:
        return <SectionAI />;
      case AppSection.QUIZZES:
        return <SectionQuizzes />;
      default:
        return <HomeSection onNavigate={setCurrentSection} />;
    }
  };

  return (
    <div className="flex h-screen w-full bg-slate-50">
      <Sidebar currentSection={currentSection} onNavigate={setCurrentSection} />
      
      <main className="flex-1 h-full overflow-hidden relative">
        {/* Mobile Header for branding */}
        <div className="md:hidden h-14 bg-white border-b flex items-center justify-center font-bold text-teal-800 shadow-sm z-10 relative">
          Nurse Shahira
        </div>
        
        <div className="h-full overflow-y-auto pb-20 md:pb-0">
          {renderContent()}
        </div>
      </main>

      <MobileNav currentSection={currentSection} onNavigate={setCurrentSection} />
    </div>
  );
};

export default App;