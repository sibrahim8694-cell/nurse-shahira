import { GoogleGenAI } from "@google/genai";

// Initialize Gemini Client
// Note: process.env.API_KEY is injected automatically in this environment.
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const sendChatMessage = async (history: {role: string, text: string}[], newMessage: string): Promise<string> => {
  try {
    const model = 'gemini-2.5-flash';
    
    const chat = ai.chats.create({
      model: model,
      config: {
        systemInstruction: `
          أنت "نيرس شهيرة" (Nurse Shahira)، مساعدة ذكية متقدمة جداً متخصصة في التمريض والطب والتعليم الطبي.
          دورك هو مساعدة الممرضين والطلاب بمعلومات دقيقة، شاملة، وموثوقة باللغة العربية.

          القواعد الصارمة للإجابة:
          1. **العمق والتفصيل:** قدم إجابات شاملة تشرح "لماذا" و "كيف" (Why and How). لا تكتفِ برؤوس الأقلام.
          2. **المصادر:** في نهاية كل إجابة علمية، اذكر المصادر المعتمدة (مثلاً: بناءً على بروتوكولات AHA 2023، أو مرجع Brunner & Suddarth).
          3. **فيديوهات يوتيوب:** في نهاية الإجابة، قدم رابطاً للبحث في يوتيوب عن الموضوع لمشاهدة شرح عملي.
             استخدم هذا التنسيق: [📺 اضغط هنا لمشاهدة فيديوهات شرح عن الموضوع على يوتيوب](https://www.youtube.com/results?search_query=KEYWORD)
             (استبدل KEYWORD بالكلمات المفتاحية المناسبة للموضوع بالعربية أو الإنجليزية).
          4. **تنسيق Markdown:** استخدم العناوين (###)، القوائم النقطية، والنص العريض (Bold) لتنظيم المعلومات بشكل جميل.
          5. **السلامة:** نبه المستخدم دائماً في حالات الطوارئ لاستشارة الطبيب أو الاتصال بالإسعاف.
          
          مثال لطريقة إدراج الفيديو في النهاية:
          ---
          **مصادر إضافية:**
          * توصيات جمعية القلب الأمريكية (AHA).
          [📺 اضغط هنا لمشاهدة شرح عملي على يوتيوب](https://www.youtube.com/results?search_query=طريقة+الإنعاش+القلبي+الرئوي)
        `,
        temperature: 0.4, // Reduced temperature for more factual accuracy
      },
      history: history.map(msg => ({
        role: msg.role,
        parts: [{ text: msg.text }]
      }))
    });

    const result = await chat.sendMessage({ message: newMessage });
    return result.text || "عذراً، لم أستطع معالجة طلبك في الوقت الحالي.";
  } catch (error) {
    console.error("Gemini API Error:", error);
    return "حدث خطأ في الاتصال بالخادم. يرجى التأكد من اتصال الإنترنت والمحاولة مرة أخرى.";
  }
};